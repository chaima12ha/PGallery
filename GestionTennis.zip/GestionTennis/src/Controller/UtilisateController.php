<?php

namespace App\Controller;

use App\Entity\Utilisate;
use App\Form\UtilisateType;
use App\Repository\UtilisateRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/utilisate')]
class UtilisateController extends AbstractController
{
    #[Route('/', name: 'app_utilisate_index', methods: ['GET'])]
    public function index(UtilisateRepository $utilisateRepository): Response
    {
        return $this->render('utilisate/index.html.twig', [
            'utilisates' => $utilisateRepository->findAll(),
        ]);
    }

    #[Route('/new', name: 'app_utilisate_new', methods: ['GET', 'POST'])]
    public function new(Request $request, UtilisateRepository $utilisateRepository): Response
    {
        $utilisate = new Utilisate();
        $form = $this->createForm(UtilisateType::class, $utilisate);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $utilisateRepository->save($utilisate, true);

            return $this->redirectToRoute('app_utilisate_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('utilisate/new.html.twig', [
            'utilisate' => $utilisate,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_utilisate_show', methods: ['GET'])]
    public function show(Utilisate $utilisate): Response
    {
        return $this->render('utilisate/show.html.twig', [
            'utilisate' => $utilisate,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_utilisate_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Utilisate $utilisate, UtilisateRepository $utilisateRepository): Response
    {
        $form = $this->createForm(UtilisateType::class, $utilisate);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $utilisateRepository->save($utilisate, true);

            return $this->redirectToRoute('app_utilisate_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('utilisate/edit.html.twig', [
            'utilisate' => $utilisate,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_utilisate_delete', methods: ['POST'])]
    public function delete(Request $request, Utilisate $utilisate, UtilisateRepository $utilisateRepository): Response
    {
        if ($this->isCsrfTokenValid('delete'.$utilisate->getId(), $request->request->get('_token'))) {
            $utilisateRepository->remove($utilisate, true);
        }

        return $this->redirectToRoute('app_utilisate_index', [], Response::HTTP_SEE_OTHER);
    }
}
