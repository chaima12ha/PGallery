<?php

namespace App\Controller;

use App\Entity\Gain;
use App\Form\GainType;
use App\Repository\GainRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/gain')]
class GainController extends AbstractController
{
    #[Route('/', name: 'app_gain_index', methods: ['GET'])]
    public function index(GainRepository $gainRepository): Response
    {
        return $this->render('gain/index.html.twig', [
            'gains' => $gainRepository->findAll(),
        ]);
    }

    #[Route('/new', name: 'app_gain_new', methods: ['GET', 'POST'])]
    public function new(Request $request, GainRepository $gainRepository): Response
    {
        $gain = new Gain();
        $form = $this->createForm(GainType::class, $gain);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $gainRepository->save($gain, true);

            return $this->redirectToRoute('app_gain_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('gain/new.html.twig', [
            'gain' => $gain,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_gain_show', methods: ['GET'])]
    public function show(Gain $gain): Response
    {
        return $this->render('gain/show.html.twig', [
            'gain' => $gain,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_gain_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Gain $gain, GainRepository $gainRepository): Response
    {
        $form = $this->createForm(GainType::class, $gain);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $gainRepository->save($gain, true);

            return $this->redirectToRoute('app_gain_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('gain/edit.html.twig', [
            'gain' => $gain,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_gain_delete', methods: ['POST'])]
    public function delete(Request $request, Gain $gain, GainRepository $gainRepository): Response
    {
        if ($this->isCsrfTokenValid('delete'.$gain->getId(), $request->request->get('_token'))) {
            $gainRepository->remove($gain, true);
        }

        return $this->redirectToRoute('app_gain_index', [], Response::HTTP_SEE_OTHER);
    }
}
