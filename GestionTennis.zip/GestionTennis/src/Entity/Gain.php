<?php

namespace App\Entity;

use App\Repository\GainRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: GainRepository::class)]
class Gain
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'gains')]
    private ?Joueur $Joueur = null;

    #[ORM\ManyToOne(inversedBy: 'gains')]
    private ?Phase $Phase = null;

    #[ORM\ManyToOne(inversedBy: 'gains')]
    private ?tournoi $tournoi = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getJoueur(): ?Joueur
    {
        return $this->Joueur;
    }

    public function setJoueur(?Joueur $Joueur): self
    {
        $this->Joueur = $Joueur;

        return $this;
    }

    public function getPhase(): ?Phase
    {
        return $this->Phase;
    }

    public function setPhase(?Phase $Phase): self
    {
        $this->Phase = $Phase;

        return $this;
    }

    public function getTournoi(): ?tournoi
    {
        return $this->tournoi;
    }

    public function setTournoi(?tournoi $tournoi): self
    {
        $this->tournoi = $tournoi;

        return $this;
    }
}
