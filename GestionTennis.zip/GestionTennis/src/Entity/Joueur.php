<?php

namespace App\Entity;

use App\Repository\JoueurRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: JoueurRepository::class)]
class Joueur
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $NomPrenom = null;

    #[ORM\Column]
    private ?int $Score = null;

    #[ORM\OneToMany(mappedBy: 'Joueur', targetEntity: Gain::class)]
    private Collection $gains;

    public function __construct()
    {
        $this->gains = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNomPrenom(): ?string
    {
        return $this->NomPrenom;
    }

    public function setNomPrenom(string $NomPrenom): self
    {
        $this->NomPrenom = $NomPrenom;

        return $this;
    }

    public function getScore(): ?int
    {
        return $this->Score;
    }

    public function setScore(int $Score): self
    {
        $this->Score = $Score;

        return $this;
    }

    /**
     * @return Collection<int, Gain>
     */
    public function getGains(): Collection
    {
        return $this->gains;
    }

    public function addGain(Gain $gain): self
    {
        if (!$this->gains->contains($gain)) {
            $this->gains->add($gain);
            $gain->setJoueur($this);
        }

        return $this;
    }

    public function removeGain(Gain $gain): self
    {
        if ($this->gains->removeElement($gain)) {
            // set the owning side to null (unless already changed)
            if ($gain->getJoueur() === $this) {
                $gain->setJoueur(null);
            }
        }

        return $this;
    }
}
