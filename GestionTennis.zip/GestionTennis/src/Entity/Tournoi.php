<?php

namespace App\Entity;

use App\Repository\TournoiRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: TournoiRepository::class)]
class Tournoi
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $NomT = null;

    #[ORM\Column(length: 255)]
    private ?string $Ville = null;

    #[ORM\OneToMany(mappedBy: 'tournoi', targetEntity: Gain::class)]
    private Collection $gains;

    public function __construct()
    {
        $this->gains = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNomT(): ?string
    {
        return $this->NomT;
    }

    public function setNomT(string $NomT): self
    {
        $this->NomT = $NomT;

        return $this;
    }

    public function getVille(): ?string
    {
        return $this->Ville;
    }

    public function setVille(string $Ville): self
    {
        $this->Ville = $Ville;

        return $this;
    }

    /**
     * @return Collection<int, Gain>
     */
    public function getGains(): Collection
    {
        return $this->gains;
    }

    public function addGain(Gain $gain): self
    {
        if (!$this->gains->contains($gain)) {
            $this->gains->add($gain);
            $gain->setTournoi($this);
        }

        return $this;
    }

    public function removeGain(Gain $gain): self
    {
        if ($this->gains->removeElement($gain)) {
            // set the owning side to null (unless already changed)
            if ($gain->getTournoi() === $this) {
                $gain->setTournoi(null);
            }
        }

        return $this;
    }
}
