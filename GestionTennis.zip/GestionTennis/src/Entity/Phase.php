<?php

namespace App\Entity;

use App\Repository\PhaseRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PhaseRepository::class)]
class Phase
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $LibellePh = null;

    #[ORM\Column]
    private ?int $NbPoints = null;

    #[ORM\OneToMany(mappedBy: 'Phase', targetEntity: Gain::class)]
    private Collection $gains;

    public function __construct()
    {
        $this->gains = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibellePh(): ?string
    {
        return $this->LibellePh;
    }

    public function setLibellePh(string $LibellePh): self
    {
        $this->LibellePh = $LibellePh;

        return $this;
    }

    public function getNbPoints(): ?int
    {
        return $this->NbPoints;
    }

    public function setNbPoints(int $NbPoints): self
    {
        $this->NbPoints = $NbPoints;

        return $this;
    }

    /**
     * @return Collection<int, Gain>
     */
    public function getGains(): Collection
    {
        return $this->gains;
    }

    public function addGain(Gain $gain): self
    {
        if (!$this->gains->contains($gain)) {
            $this->gains->add($gain);
            $gain->setPhase($this);
        }

        return $this;
    }

    public function removeGain(Gain $gain): self
    {
        if ($this->gains->removeElement($gain)) {
            // set the owning side to null (unless already changed)
            if ($gain->getPhase() === $this) {
                $gain->setPhase(null);
            }
        }

        return $this;
    }
}
